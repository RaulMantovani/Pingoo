package br.pingoo;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class RegisterActivity extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        EditText email = findViewById(R.id.email);
        EditText username = findViewById(R.id.username);
        EditText password = findViewById(R.id.password);
        Button registerButton = findViewById(R.id.registerButton);

        registerButton.setOnClickListener(v -> {
            SharedPreferences prefs = getSharedPreferences("UserCache", MODE_PRIVATE);
            if (prefs.contains(email.getText().toString())) {
                Toast.makeText(this, "Já existe um usuário com esse email", Toast.LENGTH_SHORT).show();
            } else if (prefs.contains(username.getText().toString())) {
                Toast.makeText(this, "Este usuário já existe", Toast.LENGTH_SHORT).show();
            } else {
                prefs.edit()
                    .putString(email.getText().toString(), username.getText().toString())
                    .putString(username.getText().toString(), password.getText().toString())
                    .apply();
                startActivity(new Intent(RegisterActivity.this, LoginActivity.class));
            }
        });
    }
}
