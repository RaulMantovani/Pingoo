package br.pingoo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class AdicionarAulaActivity extends AppCompatActivity {

    private EditText editMateria, editProfessor, editDiaSemana;
    private Button btnSalvar;
    private Aula aulaEditada;  // Variável para a aula que será editada

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adicionar_aula);

        editMateria = findViewById(R.id.editMateria);
        editProfessor = findViewById(R.id.editProfessor);
        editDiaSemana = findViewById(R.id.editDiaSemana);
        btnSalvar = findViewById(R.id.btnSalvarAula);

        // Verificando se a Activity foi chamada para editar uma aula
        aulaEditada = (Aula) getIntent().getSerializableExtra("aula");

        // Se for uma aula para editar, preenche os campos com os dados
        if (aulaEditada != null) {
            editMateria.setText(aulaEditada.getMateria());
            editProfessor.setText(aulaEditada.getProfessor());
            editDiaSemana.setText(aulaEditada.getDiaSemana());
            btnSalvar.setText("Atualizar Aula");  // Muda o texto do botão para 'Atualizar'
        } else {
            btnSalvar.setText("Salvar Aula");
        }

        // Ação do botão de salvar (adicionar ou atualizar)
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String materia = editMateria.getText().toString();
                String professor = editProfessor.getText().toString();
                String dia = editDiaSemana.getText().toString();

                if (materia.isEmpty() || professor.isEmpty() || dia.isEmpty()) {
                    Toast.makeText(AdicionarAulaActivity.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                List<Aula> aulas = AulaStorage.carregarAulas(AdicionarAulaActivity.this);

                if (aulaEditada != null) {
                    // Se estamos editando, atualizamos a aula
                    aulaEditada.setMateria(materia);
                    aulaEditada.setProfessor(professor);
                    aulaEditada.setDiaSemana(dia);
                    AulaStorage.salvarAulas(AdicionarAulaActivity.this, aulas);
                    Toast.makeText(AdicionarAulaActivity.this, "Aula atualizada!", Toast.LENGTH_SHORT).show();
                } else {
                    // Se estamos adicionando uma nova aula
                    int id = aulas.size() + 1;
                    Aula novaAula = new Aula(id, materia, professor, dia);
                    aulas.add(novaAula);
                    AulaStorage.salvarAulas(AdicionarAulaActivity.this, aulas);
                    Toast.makeText(AdicionarAulaActivity.this, "Aula salva!", Toast.LENGTH_SHORT).show();
                }

                finish(); // fecha a tela e volta
            }
        });
    }
}
