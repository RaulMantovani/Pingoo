package br.pingoo;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class EditarAulaActivity extends AppCompatActivity {

    private EditText editMateria, editProfessor, editDiaSemana;
    private Button btnSalvar;
    private Aula aula;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_adicionar_aula);

        // Inicializa os campos de entrada
        editMateria = findViewById(R.id.editMateria);
        editProfessor = findViewById(R.id.editProfessor);
        editDiaSemana = findViewById(R.id.editDiaSemana);
        btnSalvar = findViewById(R.id.btnSalvarAula);

        // Pega a aula passada via Intent
        aula = (Aula) getIntent().getSerializableExtra("AULA");

        // Preenche os campos com os dados da aula
        editMateria.setText(aula.getMateria());
        editProfessor.setText(aula.getProfessor());
        editDiaSemana.setText(aula.getDiaSemana());

        // Ação ao salvar as mudanças
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String materia = editMateria.getText().toString();
                String professor = editProfessor.getText().toString();
                String dia = editDiaSemana.getText().toString();

                if (materia.isEmpty() || professor.isEmpty() || dia.isEmpty()) {
                    Toast.makeText(EditarAulaActivity.this, "Preencha todos os campos", Toast.LENGTH_SHORT).show();
                    return;
                }

                // Atualiza a aula
                aula.setMateria(materia);
                aula.setProfessor(professor);
                aula.setDiaSemana(dia);

                // Atualiza a lista de aulas
                List<Aula> aulas = AulaStorage.carregarAulas(EditarAulaActivity.this);
                for (int i = 0; i < aulas.size(); i++) {
                    if (aulas.get(i).getId() == aula.getId()) {
                        aulas.set(i, aula); // Substitui a aula antiga pela nova
                        break;
                    }
                }

                // Salva as aulas atualizadas
                AulaStorage.salvarAulas(EditarAulaActivity.this, aulas);

                Toast.makeText(EditarAulaActivity.this, "Aula atualizada!", Toast.LENGTH_SHORT).show();
                finish(); // Fecha a tela e volta para a lista
            }
        });
    }
}
