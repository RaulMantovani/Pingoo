package br.pingoo;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;
import java.util.List;

public class AulasActivity extends AppCompatActivity {

    private RecyclerView recyclerView;
    private AulaAdapter adapter;
    private List<Aula> listaAulas;
    private Button btnAdicionarAula;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aulas);

        recyclerView = findViewById(R.id.recyclerViewAulas);
        btnAdicionarAula = findViewById(R.id.btnAdicionarAula);

        // Inicializa a lista (evita null)
        listaAulas = AulaStorage.carregarAulas(this);
        if (listaAulas == null) {
            listaAulas = new ArrayList<>();
        }

        // Configura o RecyclerView
        adapter = new AulaAdapter(listaAulas, new AulaAdapter.OnItemClickListener() {
            @Override
            public void onItemClick(Aula aula) {
                // Navega para a tela de visualização ou edição
                Intent intent = new Intent(AulasActivity.this, EditarAulaActivity.class);
                intent.putExtra("AULA", aula);  // Passa o objeto Aula para a nova atividade
                startActivity(intent);
            }

            @Override
            public void onEditarClick(Aula aula) {
                // Quando o botão de editar for clicado, navega para a tela de edição
                Intent intent = new Intent(AulasActivity.this, EditarAulaActivity.class);
                intent.putExtra("AULA", aula);  // Passa o objeto Aula para a nova atividade
                startActivity(intent);
            }
        });

        recyclerView.setLayoutManager(new LinearLayoutManager(this));
        recyclerView.setAdapter(adapter);

        // Botão para adicionar aula
        btnAdicionarAula.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(AulasActivity.this, AdicionarAulaActivity.class));
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();

        // Recarrega a lista atualizada
        List<Aula> aulasAtualizadas = AulaStorage.carregarAulas(this);
        if (aulasAtualizadas == null) {
            aulasAtualizadas = new ArrayList<>();
        }

        listaAulas.clear();
        listaAulas.addAll(aulasAtualizadas);
        adapter.notifyDataSetChanged();
    }
}
