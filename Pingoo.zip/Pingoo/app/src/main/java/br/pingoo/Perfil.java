package br.pingoo;

public class Perfil {
}
