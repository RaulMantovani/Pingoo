package br.pingoo;

import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import android.text.InputType;
import android.app.AlertDialog;

import androidx.appcompat.app.AppCompatActivity;

import java.util.List;

public class DetalhesAulaActivity extends AppCompatActivity {

    private Aula aula;
    private ListView listaNotas, listaAnotacoes;
    private Button btnAdicionarNota, btnAdicionarAnotacao;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detalhes_aula);

        aula = (Aula) getIntent().getSerializableExtra("AULA");

        listaNotas = findViewById(R.id.listaNotas);
        listaAnotacoes = findViewById(R.id.listaAnotacoes);
        btnAdicionarNota = findViewById(R.id.btnAdicionarNota);
        btnAdicionarAnotacao = findViewById(R.id.btnAdicionarAnotacao);

        atualizarDados();

        // Adiciona uma nova nota com descrição
        btnAdicionarNota.setOnClickListener(v -> {
            View view = getLayoutInflater().inflate(R.layout.dialog_nota, null);
            EditText inputNota = view.findViewById(R.id.inputNota);
            EditText inputDescricao = view.findViewById(R.id.inputDescricao);

            inputNota.setInputType(InputType.TYPE_CLASS_NUMBER | InputType.TYPE_NUMBER_FLAG_DECIMAL);

            new AlertDialog.Builder(this)
                    .setTitle("Adicionar Nota")
                    .setView(view)
                    .setPositiveButton("Salvar", (dialog, which) -> {
                        try {
                            float novaNota = Float.parseFloat(inputNota.getText().toString());
                            String descricao = inputDescricao.getText().toString().trim();
                            if (!descricao.isEmpty()) {
                                aula.adicionarNota(new Nota(novaNota, descricao)); // Adiciona a nota com descrição
                                salvarAula();
                                atualizarDados();
                                Toast.makeText(this, "Nota adicionada", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(this, "Descrição não pode ser vazia", Toast.LENGTH_SHORT).show();
                            }
                        } catch (NumberFormatException e) {
                            Toast.makeText(this, "Valor inválido", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });

        // Adiciona uma anotação
        btnAdicionarAnotacao.setOnClickListener(v -> {
            EditText inputAnotacao = new EditText(this);
            inputAnotacao.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            new AlertDialog.Builder(this)
                    .setTitle("Adicionar Anotação")
                    .setView(inputAnotacao)
                    .setPositiveButton("Salvar", (dialog, which) -> {
                        String anotacao = inputAnotacao.getText().toString().trim();
                        if (!anotacao.isEmpty()) {
                            aula.adicionarAnotacao(anotacao);
                            salvarAula();
                            atualizarDados();
                            Toast.makeText(this, "Anotação adicionada", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });

        // Edita ou exclui uma nota
        listaNotas.setOnItemClickListener((parent, view, position, id) -> {
            Nota nota = aula.getNotas().get(position);
            View notaView = getLayoutInflater().inflate(R.layout.dialog_nota, null);
            EditText inputNota = notaView.findViewById(R.id.inputNota);
            EditText inputDescricao = notaView.findViewById(R.id.inputDescricao);

            inputNota.setText(String.valueOf(nota.getValor()));
            inputDescricao.setText(nota.getDescricao());

            new AlertDialog.Builder(this)
                    .setTitle("Editar Nota")
                    .setView(notaView)
                    .setPositiveButton("Salvar", (dialog, which) -> {
                        try {
                            float novaNota = Float.parseFloat(inputNota.getText().toString());
                            String descricao = inputDescricao.getText().toString().trim();
                            if (!descricao.isEmpty()) {
                                nota.setValor(novaNota);
                                nota.setDescricao(descricao);
                                salvarAula();
                                atualizarDados();
                                Toast.makeText(this, "Nota atualizada", Toast.LENGTH_SHORT).show();
                            } else {
                                Toast.makeText(this, "Descrição não pode ser vazia", Toast.LENGTH_SHORT).show();
                            }
                        } catch (NumberFormatException e) {
                            Toast.makeText(this, "Valor inválido", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNeutralButton("Excluir", (dialog, which) -> {
                        aula.getNotas().remove(position);
                        salvarAula();
                        atualizarDados();
                        Toast.makeText(this, "Nota excluída", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });

        // Edita ou exclui uma anotação
        listaAnotacoes.setOnItemClickListener((parent, view, position, id) -> {
            String anotacao = aula.getAnotacoes().get(position);
            EditText inputAnotacao = new EditText(this);
            inputAnotacao.setInputType(InputType.TYPE_CLASS_TEXT | InputType.TYPE_TEXT_FLAG_MULTI_LINE);
            inputAnotacao.setText(anotacao);

            new AlertDialog.Builder(this)
                    .setTitle("Editar Anotação")
                    .setView(inputAnotacao)
                    .setPositiveButton("Salvar", (dialog, which) -> {
                        String novaAnotacao = inputAnotacao.getText().toString().trim();
                        if (!novaAnotacao.isEmpty()) {
                            aula.getAnotacoes().set(position, novaAnotacao);
                            salvarAula();
                            atualizarDados();
                            Toast.makeText(this, "Anotação atualizada", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .setNeutralButton("Excluir", (dialog, which) -> {
                        aula.getAnotacoes().remove(position);
                        salvarAula();
                        atualizarDados();
                        Toast.makeText(this, "Anotação excluída", Toast.LENGTH_SHORT).show();
                    })
                    .setNegativeButton("Cancelar", null)
                    .show();
        });
    }

    private void salvarAula() {
        List<Aula> aulas = AulaStorage.carregarAulas(this);
        for (int i = 0; i < aulas.size(); i++) {
            if (aulas.get(i).getId() == aula.getId()) {
                aulas.set(i, aula);
                break;
            }
        }
        AulaStorage.salvarAulas(this, aulas);
    }

    private void atualizarDados() {
        ArrayAdapter<Nota> adapterNotas = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, aula.getNotas());
        listaNotas.setAdapter(adapterNotas);

        ArrayAdapter<String> adapterAnotacoes = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, aula.getAnotacoes());
        listaAnotacoes.setAdapter(adapterAnotacoes);
    }
}

