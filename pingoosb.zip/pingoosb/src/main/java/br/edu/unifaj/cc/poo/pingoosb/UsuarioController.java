package br.edu.unifaj.cc.poo.pingoosb;

import org.springframework.web.bind.annotation.*;

import java.util.ArrayList;
import java.util.List;

@RestController
@RequestMapping("/api/auth")
@CrossOrigin
public class UsuarioController {

    private List<Usuario> usuarios = new ArrayList<>();

    @PostMapping("/register")
    public String register(@RequestBody Usuario novo) {
        for (Usuario u : usuarios) {
            if (u.getEmail().equalsIgnoreCase(novo.getEmail())) {
                return "Email já cadastrado.";
            }
            if (u.getUsername().equalsIgnoreCase(novo.getUsername())) {
                return "Usuário já existe.";
            }
        }

        usuarios.add(novo);
        return "Usuário registrado com sucesso.";
    }

    @PostMapping("/login")
    public String login(@RequestBody Usuario login) {
        for (Usuario u : usuarios) {
            if (u.getUsername().equals(login.getUsername()) &&
                    u.getPassword().equals(login.getPassword())) {
                return "Login bem-sucedido.";
            }
        }

        return "Usuário ou senha inválidos.";
    }

    @GetMapping("/listar")
    public List<Usuario> listar() {
        return usuarios;
    }
}
