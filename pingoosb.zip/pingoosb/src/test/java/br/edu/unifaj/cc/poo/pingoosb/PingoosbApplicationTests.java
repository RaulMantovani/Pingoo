package br.edu.unifaj.cc.poo.pingoosb;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PingoosbApplicationTests {

	@Test
	void contextLoads() {
	}

}
